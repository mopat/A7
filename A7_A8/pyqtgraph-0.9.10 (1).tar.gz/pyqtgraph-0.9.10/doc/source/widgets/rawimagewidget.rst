RawImageWidget
==============

.. autoclass:: pyqtgraph.RawImageWidget
    :members:

    .. automethod:: pyqtgraph.RawImageWidget.__init__

