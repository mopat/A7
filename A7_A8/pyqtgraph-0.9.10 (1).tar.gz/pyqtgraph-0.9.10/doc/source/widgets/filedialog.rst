FileDialog
==========

.. autoclass:: pyqtgraph.FileDialog
    :members:

    .. automethod:: pyqtgraph.FileDialog.__init__

