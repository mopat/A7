Built-in Parameter Types
========================

.. automodule:: pyqtgraph.parametertree.parameterTypes
    :members:

