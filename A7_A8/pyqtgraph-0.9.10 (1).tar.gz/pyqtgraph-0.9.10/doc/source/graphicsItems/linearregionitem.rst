LinearRegionItem
================

.. autoclass:: pyqtgraph.LinearRegionItem
    :members:

    .. automethod:: pyqtgraph.LinearRegionItem.__init__

