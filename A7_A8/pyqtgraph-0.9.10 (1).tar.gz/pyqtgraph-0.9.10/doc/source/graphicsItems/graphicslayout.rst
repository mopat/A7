GraphicsLayout
==============

.. autoclass:: pyqtgraph.GraphicsLayout
    :members:

    .. automethod:: pyqtgraph.GraphicsLayout.__init__

