ErrorBarItem
============

.. autoclass:: pyqtgraph.ErrorBarItem
    :members:

    .. automethod:: pyqtgraph.ErrorBarItem.__init__

