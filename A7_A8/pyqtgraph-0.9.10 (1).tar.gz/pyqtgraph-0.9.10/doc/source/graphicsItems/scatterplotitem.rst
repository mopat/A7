ScatterPlotItem
===============

.. autoclass:: pyqtgraph.ScatterPlotItem
    :members:

    .. automethod:: pyqtgraph.ScatterPlotItem.__init__

