GraphicsWidgetAnchor
====================

.. autoclass:: pyqtgraph.GraphicsWidgetAnchor
    :members:

    .. automethod:: pyqtgraph.GraphicsWidgetAnchor.__init__

